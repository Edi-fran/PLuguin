//jQuery("#Alumni_Exalumnos_from_create").submit(function(e)
//{
   // e.preventDefault();
   // jQuery(document).ready(function($) {
    //jQuery("#Alumni_Exalumnos_from_create").submit(function(e) {
        //e.preventDefault();
        
        // Antes de enviar la solicitud
      //  alert("Voy a enviar información");

       // jQuery.ajax({
           // url: ajax_var.url,
           // type: "POST",
          //  data: "action=create-Alumni",
           // data: jQuery(this).serialize(),
           // beforeSend: function() {
                // Antes de enviar la solicitud
                //alert("Voy a enviar información");
            //},
            //success: function($response) {
                // Cuando la solicitud es exitosa
             //   console.log($response.insert_id);
           // },
           // error: function(jqXHR, exception) {
              ///  var msg = '';
                
              //  if (jqXHR.status === 0) {
              //      msg = 'Not connect. Verify Network.';
             //   } else if (jqXHR.status == 404) {
                  //  msg = 'Requested page not found. [404]';
              //  } else if (jqXHR.status == 500) {
             //       msg = 'Internal Server Error [500].';
             //   } else if (exception == 'parsererror') {
              //      msg = 'Requested JSON parse failed.';
              //  } else if (exception == 'timeout') {
                  ///  msg = 'Time out error.';
             //   } else if (exception == 'abort') {
             //       msg = 'Ajax request aborted.';
             //   } else {
             //       msg = 'Uncaught Error.\n' + jqXHR.responseText;
             //   }
                
                // Mostrar el mensaje de error
         //       alert(msg);
          //  }
      //  });
    //});
//});


