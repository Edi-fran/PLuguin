<?php
/**
 * plugin name:Alumni_nsr
 * Autor:      Edilson Guillin
 */
require   "install.php";
require   "uninstall.php";
require   "enqueue.php";
register_activation_hook(__FILE__, 'create_table_Alumni');
register_deactivation_hook(__FILE__, 'drop_table_Alumni');

function function_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . "egresados";
    $exalumnos = $wpdb->get_results("SELECT * FROM $table_name ORDER BY titulo_obtenido ASC, ano_graduacion DESC", OBJECT);

    $tablita = "<div class='table-responsive'>";
    $tablita .= "<style>
        /* Estilos anteriores */
        .circle-icon {
            width: 80px;
            height: 80px;
            background-color: #3498db;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.2s ease-in-out;
        }

        .circle-icon i {
            font-size: 30px;
            color: blue;
        }

        .clickable-row {
            cursor: pointer;
            background-color: #e5f6fc;
            border-radius: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .clickable-row:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .details-content {
            padding: 5px;
            background: turquoise;
        }

        /* Estilos nuevos */
        .table-bordered th,
        .table-bordered td {
            border: none;
            margin: 120px;
        }

        .table-bordered th {
            text-align: center;
        }

        .table-bordered tbody tr td {
            width: 25%;
        }

        .table-bordered td {
            background-color: #e5f6fc;
            border-radius: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .table-bordered td:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
    </style>";
    
    $tablita .= "<table class='table table-bordered table-striped'>";
    $tablita .= "<tbody>";

    $columnsPerRow = 4; // Número de columnas por fila
    $rowCount = ceil(count($exalumnos) / $columnsPerRow);

    for ($row = 0; $row < $rowCount; $row++) {
        $tablita .= "<tr>";
        for ($col = 0; $col < $columnsPerRow; $col++) {
            $index = $row * $columnsPerRow + $col;
            if ($index < count($exalumnos)) {
                $exalumno = $exalumnos[$index];
                $expandedRowId = "expanded-row-$index"; // Identificador único para la fila expandida

                $tablita .= "<td>";
                $tablita .= "<div class='clickable-row floating-cell' data-target='$expandedRowId'>";
                $tablita .= "<div class='profile-frame'>";

                // Verificar si hay una foto disponible
                if (!empty($exalumno->fotografia)) {
                    $tablita .= "<img src='$exalumno->fotografia' class='img-fluid profile-image' style='width: 80px; height: 80px;'>";
                } else {
                    // Si no hay foto, agregar el icono de graduación
                    $tablita .= "<div class='circle-icon'><i class='fas fa-graduation-cap'></i></div>";
                }

                $tablita .= "</div>";
                $tablita .= "<strong class='name-cell' data-target='$expandedRowId'>$exalumno->nombre_completo</strong>";
                $tablita .= "</div>";
                $tablita .= "<div id='$expandedRowId' class='expanded-row' style='display: none;'>";
                $tablita .= "<div class='details-content'>";
                $tablita .= "<strong>Año de Graduación:</strong> $exalumno->ano_graduacion<br>";
                $tablita .= "<strong>Título Obtenido:</strong> $exalumno->titulo_obtenido<br>";
                // Agrega más campos de detalles aquí
                $tablita .= "</div>";
                $tablita .= "</div>";
                $tablita .= "</td>";
            }
        }
        $tablita .= "</tr>";
    }

    $tablita .= "</tbody>";
    $tablita .= "</table>";
    $tablita .= "</div>";

    $tablita .= "<script>
        document.addEventListener('DOMContentLoaded', function() {
            const clickableRows = document.querySelectorAll('.clickable-row');
            
            clickableRows.forEach(row => {
                row.addEventListener('click', function() {
                    const targetId = row.getAttribute('data-target');
                    const expandedRow = document.getElementById(targetId);
                    const allExpandedRows = document.querySelectorAll('.expanded-row');
                    const allCircleIcons = document.querySelectorAll('.circle-icon');

                    allExpandedRows.forEach(expanded => {
                        if (expanded.id !== targetId) {
                            expanded.style.display = 'none';
                        }
                    });

                    allCircleIcons.forEach(icon => {
                        icon.style.transform = 'scale(1)';
                    });

                    if (expandedRow) {
                        if (expandedRow.style.display === 'none') {
                            expandedRow.style.display = 'block';
                            row.querySelector('.circle-icon').style.transform = 'scale(1.1)';
                        } else {
                            expandedRow.style.display = 'none';
                            row.querySelector('.circle-icon').style.transform = 'scale(1)';
                        }
                    }
                });
            });
        });
    </script>";

    return $tablita;
}

add_shortcode('alumni_table', 'function_shortcode');











/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////



function function_shortcodeINgreso() {// permite ingresar la informacion ala base de datos
    global $wpdb;
    $table_name = $wpdb->prefix . "egresados";

    // Procesar el formulario de inserción
    if (isset($_POST['submit'])) {
        $insert_data = array(
            'cedula' => sanitize_text_field($_POST['cedula']),
            'nombre_completo' => sanitize_text_field($_POST['nombre_completo']),
            'correo_electronico' => sanitize_text_field($_POST['correo_electronico']),
            'continuacion_estudios' => sanitize_text_field($_POST['continuacion_estudios']),
            'carrera_programa' => sanitize_text_field($_POST['carrera_programa']),
            'ano_graduacion' => sanitize_text_field($_POST['ano_graduacion']),
            'titulo_obtenido' => sanitize_text_field($_POST['titulo_obtenido']),
            'nota_de_grado' => sanitize_text_field($_POST['nota_de_grado']),
            'puesto_actual' => sanitize_text_field($_POST['puesto_actual']),
            'empresa_actual' => sanitize_text_field($_POST['empresa_actual']),
            'comentarios' => sanitize_text_field($_POST['comentarios']),
            'fotografia' => sanitize_text_field($_POST['fotografia'])
           
            // Agrega aquí los campos restantes
        );

        $wpdb->insert($table_name, $insert_data);
    }

    $egresados = $wpdb->get_results("SELECT * FROM $table_name", OBJECT);

    $tablita = "";
    $tablita .= "<table width='100%' border='1px'>";
    $tablita .= "<thead>";
    // ... (resto del encabezado)
    $tablita .= "</thead>";
    $tablita .= "<tbody>";
    foreach ($egresados as $egresado) {
        // ... (contenido de las filas)
    }
    $tablita .= "</tbody>";
    $tablita .= "</table>";

    // Formulario de inserción
    ob_start();
    ?>
   <form method="POST" id="insert-data-form" class="p-4 border rounded">
    <!-- Campos del formulario con estilos de Bootstrap -->
    <h2>Datos Alumni</h2>
    <div class="mb-3">
        <input type="text" name="cedula" placeholder="Cédula" class="form-control">
    </div>
    <div class="mb-3">
        <input type="text" name="nombre_completo" placeholder="Nombres y Apellidos" class="form-control">
    </div>
    
    <div class="mb-3">
        <input type="text" name="correo_electronico" placeholder="Correo Electrónico" class="form-control">
    </div>
    <div class="mb-3">
        
        <select name="titulo_obtenido" id="titulo_obtenido" class="form-select">
            <option value="">Selecciona un título</option>
            <option value="Tecnología Superior en Diseño y gestión de base de datos">Tecnología Superior en Diseño y gestión de base de datos</option>
            <option value="Tecnología Superior en Mecánica Automotriz">Tecnología Superior en Mecánica Automotriz</option>
            <option value="Tecnología Superior en Desarrollo de Aplicaciones Web">Tecnología Superior en Desarrollo de Aplicaciones Web</option>
            <option value="Tecnología Superior en Electricidad">Tecnología Superior en Electricidad</option>
            <option value="Tecnología Superior en Contabilidad">Tecnología Superior en Contabilidad</option>
            <option value="Tecnología Superior en Contabilidad y asesoría Tributaria">Tecnología Superior en Contabilidad y asesoría Tributaria</option>
            <!-- Agrega más opciones según tus necesidades -->
        </select>
    </div>
    <div class="mb-3">
        <input type="text" name="ano_graduacion" placeholder="Año de Graduación" class="form-control">
    </div>
    <div class="mb-3">
        <input type="text" name="nota_de_grado" placeholder="Nota de Grado" class="form-control">
    </div>
    <div class="mb-3">
        <textarea name="comentarios" placeholder="Comentarios" class="form-control"></textarea>
    </div>
    
    <div class="mb-3">
        <input type="text" name="fotografia" placeholder="Fotografía" class="form-control">
    </div>
    
    <h2>Ambito Profesional</h2>
    
    
    <div class="mb-3">
        <label>¿Está trabajando actualmente?</label>
        <div class="form-check">
            <input type="checkbox" id="trabajandoActualmente" name="trabajandoActualmente" class="form-check-input">
            <label for="trabajandoActualmente" class="form-check-label">Sí, estoy trabajando actualmente</label>
        </div>
    </div>
    
    <div class="mb-3" id="camposTrabajo" style="display: none;">
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="empresa_actual" placeholder="Empresa Actual" class="form-control">
            </div>
            <div class="col-md-6">
                <input type="text" name="puesto_actual" placeholder="Puesto Actual" class="form-control">
            </div>
        </div>
    </div>
    
    <div class="mb-3">
        <label>¿Está estudiando actualmente?</label>
        <div class="form-check">
            <input type="checkbox" id="estudiandoActualmente" name="estudiandoActualmente" class="form-check-input">
            <label for="estudiandoActualmente" class="form-check-label">Sí, estoy estudiando actualmente</label>
        </div>
    </div>
    
    <div class="mb-3" id="camposEstudios" style="display: none;">
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="continuacion_estudios" placeholder="Continuación de Estudios" class="form-control">
            </div>
            <div class="col-md-6">
                <input type="text" name="carrera_programa" placeholder="Carrera o Programa" class="form-control">
            </div>
        </div>
    </div>
    
    
    <!-- Agrega aquí los campos restantes -->

    <button type="submit" name="submit" class="btn btn-primary">Guardar</button>
</form>



<script>
    const trabajandoActualmenteCheckbox = document.getElementById("trabajandoActualmente");
    const camposTrabajo = document.getElementById("camposTrabajo");
    
    const estudiandoActualmenteCheckbox = document.getElementById("estudiandoActualmente");
    const camposEstudios = document.getElementById("camposEstudios");
    
    trabajandoActualmenteCheckbox.addEventListener("change", function() {
        if (this.checked) {
            camposTrabajo.style.display = "block";
        } else {
            camposTrabajo.style.display = "none";
        }
    });
    
    estudiandoActualmenteCheckbox.addEventListener("change", function() {
        if (this.checked) {
            camposEstudios.style.display = "block";
        } else {
            camposEstudios.style.display = "none";
        }
    });
</script>



    <?php
    $insert_form = ob_get_clean();

    // Combinar la tabla y el formulario
    return $tablita . $insert_form;
}

add_shortcode('form_insert', 'function_shortcodeINgreso');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////

function function_shortcodeX() {
    global $wpdb;
    $table_name = $wpdb->prefix . "egresados";
    $egresados = $wpdb->get_results("SELECT * FROM $table_name ORDER BY titulo_obtenido ASC", OBJECT);

    $registros = '<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">'; // Inicio de la fila

    foreach ($egresados as $egresado) {
        $registro = '<div class="col">';
        $registro .= '<div class="card h-100 alumni-card border border-light rounded shadow">';
        $registro .= '<div class="card-body">';
        
        // Verifica si hay una imagen disponible
        if (!empty($egresado->fotografia)) {
            // Cambia el estilo para ajustar el tamaño de la imagen
            $registro .= '<img src="' . $egresado->fotografia . '" alt="Perfil" class="img-fluid mb-2" style="max-width: 100px; height: auto;">';
        } else {
            // Si no hay imagen, agrega un icono de persona de Font Awesome con color azul
            $registro .= '<i class="fas fa-user-circle fa-5x mb-2 text-primary"></i>';
        }
        
        $registro .= '<h5 class="card-title text-uppercase fw-bold">' . $egresado->nombre_completo . '</h5>';
        
        // Agrega campos solo si están llenos
        if (!empty($egresado->empresa_actual)) {
            $registro .= '<p class="card-text">Empresa: ' . $egresado->empresa_actual . '</p>';
        }
        
        if (!empty($egresado->puesto_actual)) {
            $registro .= '<p class="card-text">Puesto: ' . $egresado->puesto_actual . '</p>';
        }
        
        if (!empty($egresado->titulo_obtenido)) {
            $registro .= '<p class="card-text">Título: ' . $egresado->titulo_obtenido . '</p>';
        }
        
        if (!empty($egresado->continuacion_estudios)) {
            $registro .= '<p class="card-text">Continuación de Estudios: ' . $egresado->continuacion_estudios . '</p>';
        }
        
        if (!empty($egresado->carrera_programa)) {
            $registro .= '<p class="card-text">Carrera en Curso: ' . $egresado->carrera_programa . '</p>';
        }
        
        $registro .= '</div>';
        $registro .= '</div>';
        $registro .= '</div>';

        // Agregar el registro solo si tiene algún contenido
        if (strpos($registro, '<p class="card-text">') !== false) {
            $registros .= $registro;
        }
    }

    $registros .= '</div>'; // Fin de la fila

    $script = '
    <style>
    .alumni-card {
        transition: transform 0.3s ease-in-out;
        font-family: "Nombre de tu fuente", sans-serif; /* Cambia a la fuente que prefieras */
    }

    .grow {
        transform: scale(1.05);
    }

    .highlight {
        background-color: turquoise; /* Cambia a tu color deseado */
    }
    </style>
    <script>
    var alumniCards = document.querySelectorAll(".alumni-card");
    alumniCards.forEach(function(card) {
        card.addEventListener("mouseover", function() {
            card.classList.add("grow");
            card.classList.add("highlight");
        });
        card.addEventListener("mouseout", function() {
            card.classList.remove("grow");
            card.classList.remove("highlight");
        });
    });
    </script>';

    return $registros . $script;
}

add_shortcode('reseña_alumni', 'function_shortcodeX');// RESEÑA DE ESTUDIANTES
 




/////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////
//////////////////////////////////////
////////////////////////////////

//MEJORES EGRESADOS
function function_shortcode_elencia()
{
    global $wpdb;
    $table_name = $wpdb->prefix . "egresados";

    // Obtener los egresados con la mejor nota de grado por título y año de graduación
    $query = "
        SELECT e1.*
        FROM $table_name e1
        JOIN (
            SELECT titulo_obtenido, ano_graduacion, MAX(nota_de_grado) AS max_nota
            FROM $table_name
            GROUP BY titulo_obtenido, ano_graduacion
        ) e2
        ON e1.titulo_obtenido = e2.titulo_obtenido AND e1.ano_graduacion = e2.ano_graduacion AND e1.nota_de_grado = e2.max_nota
    ";
    $egresados_mejor_nota = $wpdb->get_results($query, OBJECT);

    $tablita = "";
    $tablita .= "<style>
        .card {
            animation: bounce 1s infinite;
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-20px);
            }
            60% {
                transform: translateY(-10px);
            }
        }
    </style>";
    $tablita .= "<div class='container'>";
    $tablita .= "<div class='row row-cols-1 row-cols-md-2'>";

    foreach ($egresados_mejor_nota as $egresado) {
        $tablita .= "<div class='col mb-4'>";
        $tablita .= "<div class='card rounded-3' style='border: none;'>";

        if (!empty($egresado->fotografia)) {
            $tablita .= "<img src='$egresado->fotografia' class='card-img-top zoom-effect rounded-3' alt='Foto'>";
        } else {
            // Cambiamos el icono y el estilo de fondo
            $tablita .= "<div class='text-center p-4 bg-light'>";
            $tablita .= "<i class='fas fa-graduation-cap fa-5x text-blue'></i>"; // Cambia el icono y agrega la clase de color
            $tablita .= "</div>";
        }
        
        $tablita .= "<div class='card-body bg-info text-white rounded-3'>";
        $tablita .= "<h5 class='card-title'>Tnlgo: $egresado->nombre_completo</h5>";
        $tablita .= "<p class='card-text'>Título Obtenido: $egresado->titulo_obtenido</p>";
        $tablita .= "<p class='card-text'>Nota de Grado: $egresado->nota_de_grado ";

        // Agregar los iconos de estrellas (5 estrellas)
        $tablita .= "<span>";
        for ($i = 1; $i <= 5; $i++) {
            if ($i <= $egresado->nota_de_grado) {
                $tablita .= "<i class='fas fa-star'></i>";
            } else {
                $tablita .= "<i class='far fa-star'></i>";
            }
        }
        $tablita .= "</span>";

        $tablita .= "</p>";
        $tablita .= "<p class='card-text'>Año de Graduación: $egresado->ano_graduacion</p>";
        // Puedes continuar añadiendo más detalles aquí si es necesario
        $tablita .= "</div>";
        $tablita .= "</div>";
        $tablita .= "</div>";
    }

    $tablita .= "</div>"; // Cierra la fila de columnas
    $tablita .= "</div>";

    return $tablita;
}

add_shortcode('exelencia_alumni', 'function_shortcode_elencia');


////////////////////////////////////////////////////////////////
//////////////////////////////////////////
////////////////////////

function function_shortcodefoto() {
    global $wpdb;
    $table_name = $wpdb->prefix . "egresados";

    // Procesar el formulario de inserción
    if (isset($_POST['submit'])) {
        // Manejo de la fotografía
        $upload_dir = wp_upload_dir();
        $uploaded_file = $_FILES['fotografia'];

        if ($uploaded_file['error'] == 0) {
            $file_name = sanitize_file_name($uploaded_file['name']);
            $file_path = $upload_dir['path'] . '/' . $file_name;

            if (move_uploaded_file($uploaded_file['tmp_name'], $file_path)) {
                // Crear un arreglo con los datos a insertar
                $insert_data = array(
                    'fotografia' => $upload_dir['url'] . '/' . $file_name
                );

                // Insertar en la base de datos
                $wpdb->insert($table_name, $insert_data);
            }
        }
    }

    // Mostrar la tabla de egresados
    $egresados = $wpdb->get_results("SELECT * FROM $table_name", OBJECT);

    $tablita = "<table width='100%' border='1px'>";
    $tablita .= "<thead>";
    // ... (resto del encabezado)
    $tablita .= "</thead>";
    $tablita .= "<tbody>";
    foreach ($egresados as $egresado) {
        $tablita .= "<tr>";
        // Resto de campos como antes...
       
        $tablita .= "</tr>";
    }
    $tablita .= "</tbody>";
    $tablita .= "</table>";

    // Formulario de inserción
    ob_start();
    ?>
    <form method="POST" id="insert-data-form" class="p-4 border rounded" enctype="multipart/form-data">
        <!-- Campos del formulario con estilos de Bootstrap -->
        <h2>Datos Alumni</h2>
        <!-- Resto del formulario como antes ... -->

        <div class="mb-3">
            <label for="fotografia">Subir Fotografía</label>
            <input type="file" name="fotografia" id="fotografia" class="form-control">
        </div>

        <!-- Agregar otros campos del formulario aquí -->
        
        <h2>Ambito Profesional</h2>
        <!-- Resto del formulario como antes ... -->

        <button type="submit" name="submit" class="btn btn-primary">Guardar</button>
    </form>

    <script>
    // Script JavaScript como antes ...
    </script>

    <?php
    $insert_form = ob_get_clean();

    // Combinar la tabla y el formulario
    return $tablita . $insert_form;
}

add_shortcode('fotito', 'function_shortcodefoto');


/////////////////////////////////////
////////////////////////////
//////////////////
////////////////////////////////////////////////////////////////////////////////////////////////

function buscar_egresado_form() {
    ob_start(); // Iniciar el almacenamiento en búfer de salida

    global $wpdb;

    // Procesar la entrada del formulario
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $numero = sanitize_text_field($_POST['numero']);
        $correo = sanitize_email($_POST['correo']);

        // Consultar la base de datos en busca del número y del correo electrónico
        $tabla_egresados = $wpdb->prefix . 'egresados'; // Nombre completo de la tabla con prefijo
        $consulta = $wpdb->prepare("SELECT * FROM $tabla_egresados WHERE cedula = %s AND correo_electronico = %s", $numero, $correo);
        $resultado = $wpdb->get_row($consulta);

        if ($resultado) {
            // Si se envió el formulario de actualización
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_egresado'])) {
                $nombre_completo = sanitize_text_field($_POST['nombre_completo']);
                $continuacion_estudios = sanitize_text_field($_POST['continuacion_estudios']);
                $carrera_programa = sanitize_text_field($_POST['carrera_programa']);
                $ano_graduacion = sanitize_text_field($_POST['ano_graduacion']);
                $titulo_obtenido = sanitize_text_field($_POST['titulo_obtenido']);
                $nota_de_grado = sanitize_text_field($_POST['nota_de_grado']);
                $puesto_actual = sanitize_text_field($_POST['puesto_actual']);
                $empresa_actual = sanitize_text_field($_POST['empresa_actual']);
                $comentarios = sanitize_textarea_field($_POST['comentarios']);

                // Actualizar la información en la base de datos
                $wpdb->update(
                    $tabla_egresados,
                    array(
                        'nombre_completo' => $nombre_completo,
                        'continuacion_estudios' => $continuacion_estudios,
                        'carrera_programa' => $carrera_programa,
                        'ano_graduacion' => $ano_graduacion,
                        'titulo_obtenido' => $titulo_obtenido,
                        'nota_de_grado' => $nota_de_grado,
                        'puesto_actual' => $puesto_actual,
                        'empresa_actual' => $empresa_actual,
                        'comentarios' => $comentarios
                    ),
                    array('cedula' => $numero, 'correo_electronico' => $correo)
                );

                
            }

            // Mostrar el formulario con los datos para edición
            ?>
            <form method="post" action="">
                <h1>Formulario de Actualizacion de Datos</h1>
                <input type="hidden" name="numero" value="<?php echo $numero; ?>">
                <input type="hidden" name="correo" value="<?php echo $correo; ?>">
                <label for="nombre_completo">Nombre Completo:</label>
                <input type="text" name="nombre_completo" id="nombre_completo" value="<?php echo $resultado->nombre_completo; ?>" required>
                <label for="correo_electronico">Correo Electrónico:</label>
                <input type="email" name="correo_electronico" id="correo_electronico" value="<?php echo $resultado->correo_electronico; ?>" required>
                <label for="continuacion_estudios">Continuación de Estudios:</label>
                <input type="text" name="continuacion_estudios" id="continuacion_estudios" value="<?php echo $resultado->continuacion_estudios; ?>">
                <label for="carrera_programa">Carrera o Programa:</label>
                <input type="text" name="carrera_programa" id="carrera_programa" value="<?php echo $resultado->carrera_programa; ?>">
                <label for="ano_graduacion">Año de Graduación:</label>
                <input type="text" name="ano_graduacion" id="ano_graduacion" value="<?php echo $resultado->ano_graduacion; ?>"readonly
                >
              
                <label for="titulo_obtenido">Título Obtenido:</label> <br>
                <select name="titulo_obtenido" id="titulo_obtenido">
                <option value="">Seleccione un título</option>
                <option value="Tecnología Superior en Diseño y gestión de base de datos" <?php if ($resultado->titulo_obtenido === 'Tecnología Superior en Diseño y gestión de base de datos') echo 'selected'; ?>>Tecnología Superior en Diseño y gestión de base de datos</option>
                <option value="Tecnología Superior en Mecánica Automotriz" <?php if ($resultado->titulo_obtenido === 'Tecnología Superior en Mecánica Automotriz') echo 'selected'; ?>>Tecnología Superior en Mecánica Automotriz</option>
                <option value="Tecnología Superior en Desarrollo de Aplicaciones Web" <?php if ($resultado->titulo_obtenido === 'Tecnología Superior en Desarrollo de Aplicaciones Web') echo 'selected'; ?>>Tecnología Superior en Desarrollo de Aplicaciones Web</option> 
                <option value="Tecnología Superior en Electricidad" <?php if ($resultado->titulo_obtenido === 'Tecnología Superior en Electricidad') echo 'selected'; ?>>Tecnología Superior en Electricidad</option> 
                <option value="Tecnología Superior en Contabilidad" <?php if ($resultado->titulo_obtenido === 'Tecnología Superior en Contabilidad') echo 'selected'; ?>>Tecnología Superior en Contabilidad</option> 
                <option value="Tecnología Superior en Contabilidad y asesoría Tributaria" <?php if ($resultado->titulo_obtenido === 'Tecnología Superior en Contabilidad y asesoría Tributaria') echo 'selected'; ?>>Tecnología Superior en Contabilidad y asesoría Tributaria</option> 
               
               
                <!-- Agregar más opciones según sea necesario -->

            </option>
                </select>
                <br>
                <label for="nota_de_grado">Nota de Grado:</label>
                <input type="text" name="nota_de_grado" id="nota_de_grado" value="<?php echo $resultado->nota_de_grado; ?>"readonly>
                <label for="puesto_actual">Puesto Actual:</label>
                <input type="text" name="puesto_actual" id="puesto_actual" value="<?php echo $resultado->puesto_actual; ?>">
                <label for="empresa_actual">Empresa Actual:</label>
                <input type="text" name="empresa_actual" id="empresa_actual" value="<?php echo $resultado->empresa_actual; ?>">
                <label for="comentarios">Comentarios:</label>
                <textarea name="comentarios" id="comentarios"><?php echo $resultado->comentarios; ?></textarea>
                <input type="hidden" name="actualizar_egresado" value="1" >
                <br>
                <br>
               
                <button type="submit">Actualizar</button>
             <button type="button" onclick="window.location.href = '<?php echo esc_url(home_url('//instituto-superior-tecnologico-nuestra-seora-del-rosario.local/contact-us-2/')); ?>';">Regresar</button>
            </form>
            <?php
        } else {
            echo "<p>No se encontró ningún Alumno registrado  para  mayor informacion  comunicarse con  secretaria de la institucion .</p>";
        }
    } else {
        // Mostrar el formulario de búsqueda
        ?>
        <form method="post" action="" id="login">
            <h1>Login:</h1>
        <label for="correo">Ingrese su correo electrónico del aula virtual:</label>
            <input type="email" name="correo" id="correo" required>
            <label for="numero">Ingrese el número de cedula de identidad (cédula):</label>
            <input type="text" name="numero" id="numero" minlength="10" maxlength="10" required>
    
            <br>
            <br>
            <button type="submit">verificar</button>
           
        </form>
        <?php
    }

    return ob_get_clean(); // Devolver el contenido del búfer de salida
}
add_shortcode('modificar', 'buscar_egresado_form');









    





















?>







