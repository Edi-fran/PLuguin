<?php
function create_table_Alumni() {
   global $wpdb;

   $table_name = $wpdb->prefix . "egresados";

   $sql = "CREATE TABLE $table_name (
       -- Tabla para Exalumnos
    cedula VARCHAR(10)PRIMARY KEY,
    nombre_completo VARCHAR(100),
    correo_electronico VARCHAR(100),
    continuacion_estudios VARCHAR(200),
    carrera_programa VARCHAR(100),
    ano_graduacion   VARCHAR(20),
    titulo_obtenido VARCHAR(100),
    nota_de_grado DECIMAL(3, 2),
    puesto_actual VARCHAR(100),
    empresa_actual VARCHAR(100),
    comentarios TEXT,
    fotografia BLOB
   );";
   
   require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
   dbDelta($sql);
}
