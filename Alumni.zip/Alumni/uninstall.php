<?php
function drop_table_Alumni()
{
     global $wpdb;
        $table_name = $wpdb->prefix ."egresados";
        $sql="DROP TABLE $table_name";
        $wpdb->query($sql);

}