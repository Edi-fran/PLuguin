<?
//encolamiento de  css
function Alumni_exalumnos_enqueue_css() {
    wp_register_style('Alumni-exalumnos', plugins_url('public/assets/css/style.css', __FILE__), null, '1.0', 'all');
    wp_enqueue_style('Alumni-exalumnos');

   

}
add_action('wp_enqueue_scripts', 'Alumni_exalumnos_enqueue_css');




// encolamiento de l java script
//function Alumni_exalumnos_enqueue_js() {
   // wp_register_script('Alumni_exalumnos-javascript', plugins_url('public/assets/js/main.js', __FILE__), array('jquery'), '1.0', true);
   // wp_enqueue_script('Alumni_exalumnos-javascript');


   // wp_localize_script('Alumni_exalumnos-javascript', 'ajax_var', array(
      //  'url' => admin_url('admin-ajax.php'),
        //'nonce'=>wp_create_nonce('my-ajax-nonce')

   // ));
    

//}
add_action('wp_enqueue_scripts', 'Alumni_exalumnos_enqueue_js');


function bootstrap_enqueue_css() {
   wp_register_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css', array(), '5.3.1', 'all');
   wp_enqueue_style('bootstrap');
}
add_action('wp_enqueue_scripts', 'bootstrap_enqueue_css');







//function alumni_exalumnos_enqueue_js() {
  //  wp_register_script('alumni_exalumnos-javascript', plugins_url('public/assets/js/main.js', __FILE__), array('jquery'), '1.0', true);
    //wp_enqueue_script('alumni_exalumnos-javascript');

    //wp_localize_script('alumni_exalumnos-javascript', 'ajax_var', array(
      //  'url' => admin_url('admin-ajax.php'),
        //'nonce' => wp_create_nonce('my-ajax-nonce') // Agregamos el nonce para seguridad en Ajax
    //));
//}
//add_action('wp_enqueue_scripts', 'alumni_exalumnos_enqueue_js');

function alumni_exalumnos_enqueue_js() {
    wp_register_script('alumni_exalumnos-javascript', plugins_url('public/assets/js/main.js', __FILE__), array('jquery'), '1.0', true);
    wp_enqueue_script('alumni_exalumnos-javascript');

    wp_localize_script('alumni_exalumnos-javascript', 'ajax_var', array(
        'url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('my-ajax-nonce')
    ));
}
add_action('wp_enqueue_scripts', 'alumni_exalumnos_enqueue_js');







